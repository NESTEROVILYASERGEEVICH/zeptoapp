<?php
header('Access-Control-Allow-Origin: *');
//header('Content-Type:application/javascript');
include("inc/global-cron.php");
require_once("inc/functions.php");

$db=new connection();
$db->db_conn();
//$util=new util();
//$html=new defaultsite();
//-------------------------------------------------------

// Set variables for our request
$shop = trim($_GET['shop']);
//$api_key = "4fb4703780c83a7f530ff2c59c1383fd";
//-------------------------------------------------------

$s = "select * from members where shopify_shop_name = \"".escape_string($shop)."\"  order by id desc limit 1";
//echo "<br>".__LINE__." s= ".$s; 
$qry= $db->db_query($s);
$nums= $qry->num_rows;
if ($nums > 0 ) { // exist

  $row= $db->db_fetch_array($qry);

  $id       = $row->id;
  $shopify_allow_shipping = $row->shopify_allow_shipping;
  $shopify_3h_delivery = $row->shopify_3h_delivery;
  $shopify_ndd       			= $row->shopify_ndd;
  $shopify_allow_inventory = $row->shopify_allow_inventory;
  $shopify_access_token     = $row->shopify_access_token;

  //echo "<br>".__LINE__." /id= ".$id." /shopify_3h_delivery= ".$shopify_3h_delivery." /shopify_ndd= ".$shopify_ndd." /shopify_allow_inventory= ".$shopify_allow_inventory; 

}//if ($nums > 0 ) 
else {
	die("<br>Sorry member's record not found");
}
/*
die("<br>--die--");
*/



$scopes = "read_orders, write_orders";
if($shopify_allow_shipping) {
	$scopes .= ", read_shipping, write_shipping, read_checkouts, write_checkouts";
}	
if($shopify_allow_inventory) {
	$scopes .= ", read_inventory, write_inventory, read_products, write_products";
}	
/*
$scopes = "write_shipping, write_checkouts, write_orders, read_inventory, write_inventory";
*/

$redirect_uri = "https://www.zeptoexpress.com/app/shopify/generate_token.php";

// Build install/approval URL to redirect to
$install_url = "https://" . $shop . ".myshopify.com/admin/oauth/authorize?client_id=" . SHOPIFY_API_KEY . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);

// Redirect
header("Location: " . $install_url);
die();